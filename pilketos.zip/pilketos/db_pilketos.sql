-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 09 Bulan Mei 2021 pada 01.21
-- Versi server: 10.4.14-MariaDB
-- Versi PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_pilketos`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_admin`
--

CREATE TABLE `tb_admin` (
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_admin`
--

INSERT INTO `tb_admin` (`username`, `password`) VALUES
('admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_datapilketos`
--

CREATE TABLE `tb_datapilketos` (
  `id` int(1) NOT NULL DEFAULT 1,
  `tapel` varchar(10) NOT NULL,
  `tgl` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_datapilketos`
--

INSERT INTO `tb_datapilketos` (`id`, `tapel`, `tgl`) VALUES
(1, '', '2021-10-01');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_identitassekolah`
--

CREATE TABLE `tb_identitassekolah` (
  `npsn` varchar(15) NOT NULL,
  `nm_sekolah` varchar(32) NOT NULL,
  `jln` varchar(32) DEFAULT NULL,
  `desa` varchar(32) DEFAULT NULL,
  `kec` varchar(32) DEFAULT NULL,
  `kab` varchar(32) DEFAULT NULL,
  `kpl_sekolah` varchar(50) DEFAULT NULL,
  `nip` varchar(18) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_identitassekolah`
--

INSERT INTO `tb_identitassekolah` (`npsn`, `nm_sekolah`, `jln`, `desa`, `kec`, `kab`, `kpl_sekolah`, `nip`) VALUES
('10258246', 'SMA NEGERI 1 TELUKDALAM', 'Jln. Pendidikan no. 13', 'Pasar Telukdalam', 'Teluk Dalam', 'Nias Selatan', 'Nursari Rindu Simanullang, S.Pd.MM', '196912082005022001');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_kelas`
--

CREATE TABLE `tb_kelas` (
  `kd_kelas` int(3) NOT NULL,
  `nm_kelas` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_kelas`
--

INSERT INTO `tb_kelas` (`kd_kelas`, `nm_kelas`) VALUES
(13, 'XI IA Anggrek'),
(14, 'XI IA Dahlia'),
(15, 'XI IS Aster'),
(18, 'XII IA Anggrek'),
(19, 'XII IA Dahlia'),
(20, 'XII IA Edelweis'),
(21, 'XII IA Lavender'),
(22, 'XII IS Aster'),
(23, 'XII IS Bakung'),
(24, 'XII IS Bougenville');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pilih`
--

CREATE TABLE `tb_pilih` (
  `id_pilih` int(11) NOT NULL,
  `nisn` varchar(32) NOT NULL,
  `username` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pilihan`
--

CREATE TABLE `tb_pilihan` (
  `nisn` varchar(32) NOT NULL,
  `nama` varchar(32) NOT NULL,
  `photo` varchar(32) NOT NULL,
  `no` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_pilihan`
--

INSERT INTO `tb_pilihan` (`nisn`, `nama`, `photo`, `no`) VALUES
('0053614439', 'Thean Soray Fona Manao', '0053614439.png', 1),
('0056846206', 'Gideon Gohae', '0056846206.png', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_siswa`
--

CREATE TABLE `tb_siswa` (
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `nm_siswa` varchar(32) DEFAULT NULL,
  `jk` char(1) NOT NULL,
  `kd_kelas` int(3) DEFAULT NULL,
  `hadir` varchar(12) NOT NULL DEFAULT 'Tidak Hadir'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_siswa`
--

INSERT INTO `tb_siswa` (`username`, `password`, `nm_siswa`, `jk`, `kd_kelas`, `hadir`) VALUES
('0046932896', '0046932896', 'Alfon Faozisokhi Wau', 'L', 13, 'Tidak Hadir'),
('0055279760', '0055279760', 'Alvin Kurniawan Laia', 'L', 13, 'Tidak Hadir'),
('0055949224', '0055949224', 'Angel Dwi Ayuanda Duha', 'P', 13, 'Tidak Hadir'),
('100000001', '100000001', 'Putri Elisabeth Zai', 'P', 21, 'Tidak Hadir'),
('10225602', '10225602', 'Ridwan Telaumbanua', 'L', 21, 'Tidak Hadir'),
('13424536', '13424536', 'Fikiran Halawa', 'L', 20, 'Tidak Hadir'),
('18142797', '18142797', 'Daniel Saputra Natal Zalogo', 'L', 22, 'Tidak Hadir'),
('18602752', '18602752', 'Erfan Harefa', 'L', 19, 'Tidak Hadir'),
('20244763', '20244763', 'Wilhelmus Willing Suffer Sarumah', 'L', 23, 'Tidak Hadir'),
('20244767', '20244767', 'Joy Kristofer Zagoto', 'L', 24, 'Tidak Hadir'),
('20245102', '20245102', 'Bernard Barusan Sarumaha', 'L', 23, 'Tidak Hadir'),
('20743375', '20743375', 'Filitia Ndruru', 'P', 24, 'Tidak Hadir'),
('20806297', '20806297', 'Fiktor Lirson Hondro', 'L', 19, 'Tidak Hadir'),
('21086723', '21086723', 'Putri Riska Zai', 'P', 24, 'Tidak Hadir'),
('25742345', '25742345', 'Asyvi Wardhani Duha', 'P', 24, 'Tidak Hadir'),
('26500536', '26500536', 'Niar Silis Dayanti Maduwu', 'P', 21, 'Tidak Hadir'),
('26921323', '26921323', 'Frigiditi Bawaulu', 'L', 24, 'Tidak Hadir'),
('27445583', '27445583', 'Tris Anastasia Ndruru', 'P', 19, 'Tidak Hadir'),
('3056130769', '3056130769', 'Martini Fistriani Bu\'Ulolo', 'P', 14, 'Tidak Hadir'),
('3057326173', '3057326173', 'Purina Warna Wati Laia', 'P', 15, 'Tidak Hadir'),
('31782474', '31782474', 'Mercy Nawati Sihura', 'P', 18, 'Tidak Hadir'),
('31809075', '31809075', 'Anjelita Lature', 'P', 21, 'Tidak Hadir'),
('32227483', '32227483', 'Angelina Metrianis Saota', 'P', 19, 'Tidak Hadir'),
('33426635', '33426635', 'Sesilia Wau', 'P', 18, 'Tidak Hadir'),
('34200245', '34200245', 'Rudolf Zakaria Zagoto', 'L', 20, 'Tidak Hadir'),
('34289205', '34289205', 'Religius Hironimus Ziraluo', 'L', 23, 'Tidak Hadir'),
('34609301', '34609301', 'Eva Sosa Idaman Lature', 'P', 22, 'Tidak Hadir'),
('35140514', '35140514', 'Otniel Bram Fransiskus Fau', 'L', 20, 'Tidak Hadir'),
('35189058', '35189058', 'Yulianus Yantonius Laia', 'L', 23, 'Tidak Hadir'),
('35239201', '35239201', 'Maryanto Darwin Serius Gulo', 'L', 15, 'Tidak Hadir'),
('35908716', '35908716', 'Ajaib Putra Jaya Saota', 'L', 21, 'Tidak Hadir'),
('36131617', '36131617', 'Tanti Sri Jayanti Sarumaha', 'P', 23, 'Tidak Hadir'),
('36416272', '36416272', 'Fomaembarasi Buulolo', 'P', 19, 'Tidak Hadir'),
('36416836', '36416836', 'Elkania Samaria Gee', 'P', 22, 'Tidak Hadir'),
('36610220', '36610220', 'Gestriani Gulo', 'P', 22, 'Tidak Hadir'),
('36612801', '36612801', 'Lilismawati Duha', 'P', 22, 'Tidak Hadir'),
('36674916', '36674916', 'Krisna Handayani Duha', 'P', 23, 'Tidak Hadir'),
('36674931', '36674931', 'Michael Jackson Telaumbanua', 'L', 22, 'Tidak Hadir'),
('37104651', '37104651', 'Dionisia Diasmara Harita', 'P', 19, 'Tidak Hadir'),
('38281011', '38281011', 'Agusman Saferius Wau', 'L', 20, 'Tidak Hadir'),
('38374847', '38374847', 'Lenaria Wehalo', 'P', 21, 'Tidak Hadir'),
('38478104', '38478104', 'Yantonius Sihura', 'L', 22, 'Tidak Hadir'),
('38478870', '38478870', 'Juliarni Gulo', 'P', 19, 'Tidak Hadir'),
('38511325', '38511325', 'Braiyean Haria', 'L', 22, 'Tidak Hadir'),
('38779632', '38779632', 'Christiafelia Tabita Solideo Isa', 'P', 23, 'Tidak Hadir'),
('38822816', '38822816', 'Zefanya Sarumaha', 'L', 21, 'Tidak Hadir'),
('38945890', '38945890', 'Grace Immanuel Majesty Lature', 'P', 22, 'Tidak Hadir'),
('39030959', '39030959', 'Rian Refanza Lumbantoruan', 'L', 21, 'Tidak Hadir'),
('39403385', '39403385', 'Riska Monika Satofona', 'P', 21, 'Tidak Hadir'),
('39684343', '39684343', 'Anggeli Maduwu', 'P', 24, 'Tidak Hadir'),
('39747807', '39747807', 'Paulina Natalia Sarumaha', 'P', 23, 'Tidak Hadir'),
('40976346', '40976346', 'Eksal Leonard Ndruru', 'L', 24, 'Tidak Hadir'),
('41046586', '41046586', 'Rahel Rafikaria Zamili', 'P', 23, 'Tidak Hadir'),
('41220062', '41220062', 'Rikamawati Hulu', 'P', 20, 'Tidak Hadir'),
('41282104', '41282104', 'Anjjelita Lombu', 'P', 14, 'Tidak Hadir'),
('41326200', '41326200', 'Benaria Duha', 'P', 18, 'Tidak Hadir'),
('41440937', '41440937', 'Cindy Arlin Wau', 'P', 19, 'Tidak Hadir'),
('41459161', '41459161', 'Jonathan Setiawan Ndruru', 'L', 19, 'Tidak Hadir'),
('41501753', '41501753', 'Dwinta Rezki Berliana Hulu', 'P', 21, 'Tidak Hadir'),
('41542260', '41542260', 'Delon Vaness Gabriel Buulolo', 'L', 18, 'Tidak Hadir'),
('41643466', '41643466', 'William Jen Eulogia Laia', 'L', 21, 'Tidak Hadir'),
('41725187', '41725187', 'Almirnaria Maduwu', 'P', 21, 'Tidak Hadir'),
('41864625', '41864625', 'Kesabaran Duha', 'L', 24, 'Tidak Hadir'),
('41918522', '41918522', 'Gusti Nanda Kristiani Manao', 'P', 22, 'Tidak Hadir'),
('41942082', '41942082', 'Fresh Krist Wit Nesty Sarumaha', 'P', 24, 'Tidak Hadir'),
('41959245', '41959245', 'Azarya Rose Mariel Telaumbanua', 'P', 18, 'Tidak Hadir'),
('41989299', '41989299', 'Adrianus Rivaldin Sarumaha', 'L', 23, 'Tidak Hadir'),
('42025059', '42025059', 'Rismawati Laia', 'P', 20, 'Tidak Hadir'),
('42050149', '42050149', 'Vinca Dwicahyani Laia', 'P', 18, 'Tidak Hadir'),
('42060029', '42060029', 'Fernis Hati Gaho', 'P', 23, 'Tidak Hadir'),
('42124087', '42124087', 'Putri Rindiani Halawa', 'P', 24, 'Tidak Hadir'),
('42180514', '42180514', 'Yuliana Citra Sarumaha', 'P', 21, 'Tidak Hadir'),
('42193952', '42193952', 'Cindy Azhar N. Sarumaha', 'P', 18, 'Tidak Hadir'),
('42208615', '42208615', 'Emon Citra Damai Ge\'e', 'L', 22, 'Tidak Hadir'),
('42211871', '42211871', 'Rahima Nur Tanjung', 'P', 24, 'Tidak Hadir'),
('42211883', '42211883', 'Rizka Amanah Buaya', 'P', 18, 'Tidak Hadir'),
('42211902', '42211902', 'Rizky Ikhwan Tanjung', 'L', 18, 'Tidak Hadir'),
('42212053', '42212053', 'Yuniar Nurul Hasnah', 'P', 18, 'Tidak Hadir'),
('42230735', '42230735', 'Emanuel Sarumaha', 'L', 15, 'Tidak Hadir'),
('42346582', '42346582', 'Andreas Laia', 'L', 21, 'Tidak Hadir'),
('42484642', '42484642', 'Winda Patricia Manao', 'P', 14, 'Tidak Hadir'),
('42504852', '42504852', 'Pia Betris Sarumaha', 'P', 19, 'Tidak Hadir'),
('42579898', '42579898', 'Yurli Bohalima', 'P', 22, 'Tidak Hadir'),
('42583640', '42583640', 'Ethaneel Timothy Nitouozaro Wau', 'L', 18, 'Tidak Hadir'),
('42590099', '42590099', 'Alex Frisman Saota', 'L', 18, 'Tidak Hadir'),
('42606600', '42606600', 'Okhotada Yosefo Laia', 'L', 15, 'Tidak Hadir'),
('42622110', '42622110', 'Lisnawati Giawa', 'P', 23, 'Tidak Hadir'),
('42798361', '42798361', 'Amelia Septiani Duha', 'P', 24, 'Tidak Hadir'),
('42798536', '42798536', 'Daniel Loi', 'P', 21, 'Tidak Hadir'),
('42798541', '42798541', 'Enjelita Zalogo', 'P', 22, 'Tidak Hadir'),
('42798858', '42798858', 'Miktam Vamosikhada Laia', 'L', 18, 'Tidak Hadir'),
('42799179', '42799179', 'Eliani Angela Cemsyah Duha', 'P', 23, 'Tidak Hadir'),
('42813836', '42813836', 'Gita Slavina Laia', 'P', 20, 'Tidak Hadir'),
('42818404', '42818404', 'Theodorus Idola Harita', 'L', 19, 'Tidak Hadir'),
('42821177', '42821177', 'Desna Karolin Buulolo', 'P', 19, 'Tidak Hadir'),
('42888402', '42888402', 'Sarinulo Bago', 'P', 24, 'Tidak Hadir'),
('42896772', '42896772', 'Aswan Julpiter Putra Zamili', 'L', 18, 'Tidak Hadir'),
('42923476', '42923476', 'Edwina Risna Susanti Sihura', 'P', 21, 'Tidak Hadir'),
('43264466', '43264466', 'Nadya Flower Arivia Br. Pangarib', 'P', 18, 'Tidak Hadir'),
('43337980', '43337980', 'Ade Yuspita Laoli', 'P', 21, 'Tidak Hadir'),
('43339137', '43339137', 'Priska Zendrato', 'P', 23, 'Tidak Hadir'),
('43360103', '43360103', 'Erna Dilasitiani Zamili', 'P', 14, 'Tidak Hadir'),
('43608389', '43608389', 'Laurensia Putrinela Manao', 'P', 18, 'Tidak Hadir'),
('43776023', '43776023', 'Naomi Emerita Fosilai Dachi', 'P', 18, 'Tidak Hadir'),
('43814881', '43814881', 'Marcellino Gabriel Asmoro', 'L', 19, 'Tidak Hadir'),
('43831402', '43831402', 'Meykris Triyan Putera Lase', 'L', 20, 'Tidak Hadir'),
('43831405', '43831405', 'Nielman Putra Simanungkalit', 'L', 19, 'Tidak Hadir'),
('43831489', '43831489', 'Ade Putra Sarumaha', 'L', 19, 'Tidak Hadir'),
('43927060', '43927060', 'Hostiana Ndruru', 'P', 20, 'Tidak Hadir'),
('44041559', '44041559', 'Willing Onist Sang Putra Laia', 'L', 20, 'Tidak Hadir'),
('44124739', '44124739', 'Bernade Septiani Luaha', 'P', 23, 'Tidak Hadir'),
('44279279', '44279279', 'Andreas Dwi Putra Dachi', 'L', 20, 'Tidak Hadir'),
('44652633', '44652633', 'Winning Aster Gowasa', 'P', 21, 'Tidak Hadir'),
('44660906', '44660906', 'Angelina Delfin Cahyani Gea', 'P', 21, 'Tidak Hadir'),
('44699790', '44699790', 'Silvester Mewaltus Wehalo', 'L', 23, 'Tidak Hadir'),
('44731624', '44731624', 'Rado Parman Zamili', 'L', 24, 'Tidak Hadir'),
('44731626', '44731626', 'Saprianto Harita', 'L', 24, 'Tidak Hadir'),
('44732075', '44732075', 'Aida Fitra Halawa', 'P', 22, 'Tidak Hadir'),
('44732107', '44732107', 'Emanuel Yantonius Wehalo', 'L', 23, 'Tidak Hadir'),
('44732233', '44732233', 'Ronal Wehalo', 'L', 24, 'Tidak Hadir'),
('44742350', '44742350', 'Jhon Kanselman Zamili', 'L', 20, 'Tidak Hadir'),
('44848561', '44848561', 'Nesra Marta Intan Lature', 'P', 22, 'Tidak Hadir'),
('45009029', '45009029', 'Margaretha Marwanwati Gowasa', 'P', 15, 'Tidak Hadir'),
('45034375', '45034375', 'Ifaano Buasisokhi Harita', 'L', 18, 'Tidak Hadir'),
('45048367', '45048367', 'Sarah Nisela Natalia Lase', 'P', 20, 'Tidak Hadir'),
('45060800', '45060800', 'Anicetus Andri Kusman Wau', 'L', 23, 'Tidak Hadir'),
('45122507', '45122507', 'Nikodemus Sarumaha', 'L', 24, 'Tidak Hadir'),
('45358832', '45358832', 'Riswan Arianto Zaita', 'L', 24, 'Tidak Hadir'),
('45371265', '45371265', 'Delon Flafius Fau', 'L', 23, 'Tidak Hadir'),
('45373394', '45373394', 'Ester Karmila Ndruru', 'P', 22, 'Tidak Hadir'),
('45373785', '45373785', 'Nonia Ziraluo', 'P', 21, 'Tidak Hadir'),
('45375279', '45375279', 'Tolstoy Adolf Kristian Gee', 'L', 21, 'Tidak Hadir'),
('45408784', '45408784', 'Landas Albertus Wau', 'L', 24, 'Tidak Hadir'),
('45589865', '45589865', 'Hery Try Sandy Sarumaha', 'L', 22, 'Tidak Hadir'),
('45604471', '45604471', 'Priyaman Laowo', 'L', 22, 'Tidak Hadir'),
('45707579', '45707579', 'Fitorius Gaurifa', 'L', 18, 'Tidak Hadir'),
('45806821', '45806821', 'Febrina Dian Sari Duha', 'P', 21, 'Tidak Hadir'),
('45898858', '45898858', 'Agung Prasetya Putra Sarumaha', 'L', 22, 'Tidak Hadir'),
('45908007', '45908007', 'Optimis Manao', 'P', 22, 'Tidak Hadir'),
('46087549', '46087549', 'Kornelia Irdawati Laia', 'P', 19, 'Tidak Hadir'),
('46236810', '46236810', 'Olwan Fiktor Duha', 'L', 22, 'Tidak Hadir'),
('46341238', '46341238', 'Rahel Trinitatis Waoma', 'P', 22, 'Tidak Hadir'),
('46357896', '46357896', 'Nikodemus Ndruru', 'L', 23, 'Tidak Hadir'),
('46380065', '46380065', 'Arnoldus Jul Keflin Sarumaha', 'L', 19, 'Tidak Hadir'),
('46394304', '46394304', 'Gregorius Gavriel', 'L', 21, 'Tidak Hadir'),
('46408672', '46408672', 'Aulia Fitriani', 'P', 19, 'Tidak Hadir'),
('46525978', '46525978', 'Wilhelmina Duha', 'P', 20, 'Tidak Hadir'),
('46586900', '46586900', 'Niar Kartika Sari Zalogo', 'P', 22, 'Tidak Hadir'),
('46636069', '46636069', 'Eligusman Buulolo', 'L', 24, 'Tidak Hadir'),
('46764067', '46764067', 'Etanim Duha', 'P', 20, 'Tidak Hadir'),
('46769426', '46769426', 'Jolva Hendri Yanto Duha', 'L', 20, 'Tidak Hadir'),
('46788648', '46788648', 'Brando Tenafona Wau', 'L', 22, 'Tidak Hadir'),
('46809219', '46809219', 'Michaele Itorotodo Telaumbanua', 'L', 20, 'Tidak Hadir'),
('46932896', '46932896', 'Alfon Faozisokhi Wau', 'L', 13, 'Tidak Hadir'),
('46935124', '46935124', 'Roslin Kristiani Sarumaha', 'P', 20, 'Tidak Hadir'),
('47176057', '47176057', 'Zesni Susanti Duha', 'P', 20, 'Tidak Hadir'),
('47259206', '47259206', 'Grace Princess Olai Dachi', 'P', 22, 'Tidak Hadir'),
('47319952', '47319952', 'Rosmawati Laia', 'P', 20, 'Tidak Hadir'),
('47509283', '47509283', 'Hilaria Isihati Sarumaha', 'P', 19, 'Tidak Hadir'),
('47542030', '47542030', 'Kelvin Decta Matius Fau', 'L', 24, 'Tidak Hadir'),
('47629376', '47629376', 'Putri Sastrawati Buulolo', 'P', 19, 'Tidak Hadir'),
('47695787', '47695787', 'Dhea Epryana Sihura', 'P', 13, 'Tidak Hadir'),
('47774983', '47774983', 'Helfen Michael Zuschnell Laia', 'L', 22, 'Tidak Hadir'),
('47793723', '47793723', 'Clara Septa Fransiska Daliwu', 'P', 23, 'Tidak Hadir'),
('47914956', '47914956', 'Sindi Kristin Dama Yanti Gaurifa', 'P', 20, 'Tidak Hadir'),
('47957445', '47957445', 'Elviana Yotifianis Wau', 'P', 19, 'Tidak Hadir'),
('48053471', '48053471', 'Kanisius Armentonius Sarumaha', 'L', 23, 'Tidak Hadir'),
('48066507', '48066507', 'Riswan Hobi Lature', 'L', 21, 'Tidak Hadir'),
('48069834', '48069834', 'Elwinda Krisnawati Laia', 'P', 23, 'Tidak Hadir'),
('48071804', '48071804', 'Kevin Krisna Laia', 'L', 13, 'Tidak Hadir'),
('48095617', '48095617', 'Cessya Juni Florence Gulo', 'P', 22, 'Tidak Hadir'),
('48117674', '48117674', 'Septiaman Karya Damai Hia', 'L', 19, 'Tidak Hadir'),
('48133788', '48133788', 'Olivia Magdalena Simanullang', 'P', 18, 'Tidak Hadir'),
('48185669', '48185669', 'Doris Van Ardiansa Hondro', 'L', 22, 'Tidak Hadir'),
('48341835', '48341835', 'Asiria Halawa', 'P', 21, 'Tidak Hadir'),
('48424994', '48424994', 'Ari Anita Kristiani Loi', 'P', 18, 'Tidak Hadir'),
('48427054', '48427054', 'Yuniar Gee', 'P', 21, 'Tidak Hadir'),
('48465437', '48465437', 'Bernaded Gustiniar Sarumaha', 'P', 19, 'Tidak Hadir'),
('48572789', '48572789', 'Estyut Sarumaha', 'P', 19, 'Tidak Hadir'),
('48589478', '48589478', 'Flora Melfin Sriyanti Duha', 'P', 14, 'Tidak Hadir'),
('48610522', '48610522', 'Zulvian Putra Emanuel Duha', 'L', 18, 'Tidak Hadir'),
('48613294', '48613294', 'Serlyanis Duha', 'P', 21, 'Tidak Hadir'),
('48735171', '48735171', 'Ferianis Lature', 'P', 20, 'Tidak Hadir'),
('48793999', '48793999', 'Kerin Hapukh Humendru', 'P', 13, 'Tidak Hadir'),
('48858668', '48858668', 'Mikhael Pandi Nehe', 'L', 20, 'Tidak Hadir'),
('48933962', '48933962', 'Sofuzatulo Wau', 'L', 24, 'Tidak Hadir'),
('49025206', '49025206', 'Jessika Telaumbanua', 'P', 20, 'Tidak Hadir'),
('49026866', '49026866', 'Sermon Gun Kevin Maduwu', 'L', 23, 'Tidak Hadir'),
('49032162', '49032162', 'Shinta Surwahyuni Telaumbanua', 'P', 22, 'Tidak Hadir'),
('49070987', '49070987', 'Petra Yarlina Gowasa', 'P', 13, 'Tidak Hadir'),
('49249895', '49249895', 'Apfia Neldayanti Zai', 'P', 21, 'Tidak Hadir'),
('49252800', '49252800', 'Yesriahna Maria Magdalena Lature', 'P', 19, 'Tidak Hadir'),
('49296446', '49296446', 'Kristoforus Sikoli Hondro', 'L', 23, 'Tidak Hadir'),
('49320530', '49320530', 'Ruthmala Kristina Harefa', 'P', 18, 'Tidak Hadir'),
('49394639', '49394639', 'Nilda Claresta Saota', 'P', 18, 'Tidak Hadir'),
('49396790', '49396790', 'Beny Duha', 'L', 24, 'Tidak Hadir'),
('49397769', '49397769', 'Fransiskus Luahambowo', 'L', 19, 'Tidak Hadir'),
('49536025', '49536025', 'Theofanus Rodin Susanto Harita', 'L', 23, 'Tidak Hadir'),
('49706834', '49706834', 'Imelda Ribka Lutima Zagoto', 'P', 21, 'Tidak Hadir'),
('49859638', '49859638', 'Iwan Charloswan Duha', 'L', 14, 'Tidak Hadir'),
('49865133', '49865133', 'Nariami Wau', 'P', 15, 'Tidak Hadir'),
('50397641', '50397641', 'Ribcha Nigia Nawuazitarry Duha', 'P', 18, 'Tidak Hadir'),
('50397646', '50397646', 'Apolos Valentino Duha', 'L', 21, 'Tidak Hadir'),
('50411785', '50411785', 'Widyan Dipin Mendrofa', 'P', 20, 'Tidak Hadir'),
('50417264', '50417264', 'Ahmad Sidik Duha', 'L', 24, 'Tidak Hadir'),
('50417857', '50417857', 'Selfira Febrianti Laia', 'P', 18, 'Tidak Hadir'),
('50417858', '50417858', 'Syaifullah Waruwu', 'L', 24, 'Tidak Hadir'),
('50451832', '50451832', 'Sri Welni Febrianis Saota', 'P', 20, 'Tidak Hadir'),
('50470802', '50470802', 'Gian Putra Krismas Larosa', 'L', 21, 'Tidak Hadir'),
('50470825', '50470825', 'Rahel Adilia Duha', 'P', 15, 'Tidak Hadir'),
('50470840', '50470840', 'Angela Tri Barasi Harita', 'P', 23, 'Tidak Hadir'),
('50470841', '50470841', 'Ardy Borisman Gowasa', 'L', 24, 'Tidak Hadir'),
('50474906', '50474906', 'Silvester Fa\'Atulododo Dakhi', 'L', 19, 'Tidak Hadir'),
('50537888', '50537888', 'Cyndy Margaret Harita', 'P', 20, 'Tidak Hadir'),
('50538600', '50538600', 'Amonius Luahambowo', 'L', 24, 'Tidak Hadir'),
('50538615', '50538615', 'Febriani Gaho', 'P', 24, 'Tidak Hadir'),
('50538654', '50538654', 'Windi Permatasari Duha', 'P', 19, 'Tidak Hadir'),
('50735447', '50735447', 'Trisnawati Zamili', 'P', 20, 'Tidak Hadir'),
('50754222', '50754222', 'Lestari Ndruru', 'P', 14, 'Tidak Hadir'),
('51104918', '51104918', 'Paskalia Jesica Gowasa', 'P', 23, 'Tidak Hadir'),
('51163688', '51163688', 'Henokh Wau', 'L', 18, 'Tidak Hadir'),
('51185044', '51185044', 'Invo Kavit Harefa', 'L', 15, 'Tidak Hadir'),
('51233868', '51233868', 'Jonathan Daniel Halawa', 'L', 15, 'Tidak Hadir'),
('51235476', '51235476', 'Kennan Daniel Telaumbanua', 'L', 24, 'Tidak Hadir'),
('51406565', '51406565', 'Beatus Noyasarowamati Fau', 'L', 23, 'Tidak Hadir'),
('51523890', '51523890', 'Indah Putri Evani Bali', 'P', 14, 'Tidak Hadir'),
('51627840', '51627840', 'Henny Ratna Wati Sarumaha', 'P', 14, 'Tidak Hadir'),
('51716412', '51716412', 'Eureka Hulu', 'P', 15, 'Tidak Hadir'),
('51738477', '51738477', 'Elisabeth Tri Balaki Ndruru', 'P', 13, 'Tidak Hadir'),
('51909533', '51909533', 'Lusia Yus Arimawati Nehe', 'P', 15, 'Tidak Hadir'),
('51966164', '51966164', 'Dewi Nasrani Bu\'Ulolo', 'P', 22, 'Tidak Hadir'),
('52047230', '52047230', 'Otniel Limiwilaes Sarumaha', 'L', 15, 'Tidak Hadir'),
('52135299', '52135299', 'Devi Shinta Swandaryani Wau', 'P', 14, 'Tidak Hadir'),
('52152050', '52152050', 'Jan Merlin Maduwu', 'P', 13, 'Tidak Hadir'),
('52161286', '52161286', 'Samuel Winston Manulang', 'P', 14, 'Tidak Hadir'),
('52333044', '52333044', 'Anofula Grata Davao Duha', 'L', 13, 'Tidak Hadir'),
('52472256', '52472256', 'Yolanda Ikaskartika P. Sarumaha', 'P', 19, 'Tidak Hadir'),
('52498912', '52498912', 'M. Aidil Bimantara Siregar', 'L', 13, 'Tidak Hadir'),
('52514602', '52514602', 'Trilin Krisniat Laia', 'P', 22, 'Tidak Hadir'),
('52739986', '52739986', 'Puspitasari Gempril Nitasi Bago', 'P', 20, 'Tidak Hadir'),
('52901566', '52901566', 'Amanda Winter Sonata Luahambowo', 'P', 18, 'Tidak Hadir'),
('52998433', '52998433', 'Gilbert Stevan Memories Hulu', 'L', 20, 'Tidak Hadir'),
('53226586', '53226586', 'Anna Maria Laia', 'P', 15, 'Tidak Hadir'),
('53308486', '53308486', 'Monika Marsanda Nehe', 'P', 14, 'Tidak Hadir'),
('53314088', '53314088', 'Mitra Ningsi Zebua', 'P', 15, 'Tidak Hadir'),
('53365088', '53365088', 'Novepilda Sari Sihura', 'P', 15, 'Tidak Hadir'),
('53583960', '53583960', 'Wulan Hotnauli Lature', 'P', 13, 'Tidak Hadir'),
('53608259', '53608259', 'Pia Bertha Sarumaha', 'P', 22, 'Tidak Hadir'),
('53614439', '53614439', 'Thean Soray Fona Manao', 'L', 13, 'Tidak Hadir'),
('53668097', '53668097', 'Asnidar Harefa', 'P', 14, 'Tidak Hadir'),
('53725583', '53725583', 'Yuliana Rosa Herliana Laia', 'P', 18, 'Tidak Hadir'),
('53746684', '53746684', 'Cipta Mulia Putra Ziraluo', 'L', 15, 'Tidak Hadir'),
('53782011', '53782011', 'Cindy Claudia Talunohi', 'P', 13, 'Tidak Hadir'),
('53941786', '53941786', 'Anjelika Halawa', 'P', 15, 'Tidak Hadir'),
('53979621', '53979621', 'Agnes Monika Bali', 'P', 14, 'Tidak Hadir'),
('54050368', '54050368', 'Kihas Tuberta Fransiskus Laia', 'L', 14, 'Tidak Hadir'),
('54079617', '54079617', 'Yahya Kuslimade Charisman Saruma', 'L', 23, 'Tidak Hadir'),
('54125010', '54125010', 'Felita Delfina Wau', 'P', 18, 'Tidak Hadir'),
('54395092', '54395092', 'Flora Sinta Sarumaha', 'P', 19, 'Tidak Hadir'),
('54402363', '54402363', 'Yuberman Nazara', 'L', 15, 'Tidak Hadir'),
('54442867', '54442867', 'Maria Dolorosa Lilis Festiani Fa', 'P', 18, 'Tidak Hadir'),
('54547733', '54547733', 'Karlina Wau', 'P', 20, 'Tidak Hadir'),
('54562917', '54562917', 'Jessy Gracia Soraina Dachi', 'P', 13, 'Tidak Hadir'),
('54617714', '54617714', 'Ilen Sartika Madala Duha', 'P', 15, 'Tidak Hadir'),
('54681081', '54681081', 'Kenny Afrina Wau', 'P', 15, 'Tidak Hadir'),
('54696247', '54696247', 'Maria Elsisna Sarumaha', 'P', 18, 'Tidak Hadir'),
('54759371', '54759371', 'Adven Keinal Duha', 'L', 24, 'Tidak Hadir'),
('54801307', '54801307', 'Rayhan Maulana H. Telaumbanua', 'L', 18, 'Tidak Hadir'),
('54961378', '54961378', 'Kris Agustiaman Buulolo', 'L', 15, 'Tidak Hadir'),
('54972946', '54972946', 'Yoas Gowasa', 'L', 15, 'Tidak Hadir'),
('55095730', '55095730', 'Sylvia Yolanda Sri Yanti Hia', 'P', 20, 'Tidak Hadir'),
('55125880', '55125880', 'Meydian Angelin S. Gowasa', 'P', 24, 'Tidak Hadir'),
('55152205', '55152205', 'Laurensia Seprias Laia', 'P', 13, 'Tidak Hadir'),
('55279760', '55279760', 'Alvin Kurniawan Laia', 'L', 13, 'Tidak Hadir'),
('55291004', '55291004', 'Yosevin Fonitawo Bago', 'P', 19, 'Tidak Hadir'),
('55298237', '55298237', 'Matius Lastchrist Zagoto', 'L', 19, 'Tidak Hadir'),
('55324516', '55324516', 'Janiartika Sihura', 'P', 23, 'Tidak Hadir'),
('55332667', '55332667', 'Florensia Feronika Bohalima', 'P', 19, 'Tidak Hadir'),
('55399087', '55399087', 'Riang Hati Putri Sejati Giawa', 'P', 13, 'Tidak Hadir'),
('55409346', '55409346', 'Rosalina Melianis Bu\'ulolo', 'P', 14, 'Tidak Hadir'),
('55520996', '55520996', 'Griandani Zagoto', 'P', 24, 'Tidak Hadir'),
('55745969', '55745969', 'Willhelmin Widya Astuti Fau', 'P', 15, 'Tidak Hadir'),
('55779682', '55779682', 'Natalia Julfania Putri Gaurifa', 'P', 18, 'Tidak Hadir'),
('55801225', '55801225', 'Rismawati Sarumaha', 'P', 22, 'Tidak Hadir'),
('55949224', '55949224', 'Angel Dwi Ayuanda Duha', 'P', 13, 'Tidak Hadir'),
('55976253', '55976253', 'Ribka Nivitarianis Halawa', 'P', 14, 'Tidak Hadir'),
('56034352', '56034352', 'Gabriel Angeline Nehe', 'L', 15, 'Tidak Hadir'),
('56059293', '56059293', 'Ricky Efisiensi Duha', 'L', 20, 'Tidak Hadir'),
('56088009', '56088009', 'Patricia Cynthia Hondro', 'P', 13, 'Tidak Hadir'),
('56135226', '56135226', 'Jessica Putri Febriyanti Sarumah', 'P', 18, 'Tidak Hadir'),
('56486380', '56486380', 'Kebersamaan Talunohi', 'L', 13, 'Tidak Hadir'),
('56507429', '56507429', 'Avorey Bias Agung Valentino Duha', 'L', 13, 'Tidak Hadir'),
('56552270', '56552270', 'Frendy Taomasio Duha', 'L', 13, 'Tidak Hadir'),
('56573486', '56573486', 'Maria Angela Bago', 'P', 23, 'Tidak Hadir'),
('56631323', '56631323', 'Vivid Pretty Mayrisoda Duha', 'P', 15, 'Tidak Hadir'),
('56764226', '56764226', 'Delman Gaho', 'L', 24, 'Tidak Hadir'),
('56846206', '56846206', 'Gideon Gohae', 'L', 15, 'Tidak Hadir'),
('56874983', '56874983', 'Theresia Jefanya Putri Sarumaha', 'P', 14, 'Tidak Hadir'),
('56975972', '56975972', 'Akil Didik Gaurifa', 'L', 21, 'Tidak Hadir'),
('57088497', '57088497', 'Andrey Firstman Agnidi Laia', 'L', 21, 'Tidak Hadir'),
('57147108', '57147108', 'Marsella Festika Bawaulu', 'P', 19, 'Tidak Hadir'),
('57158463', '57158463', 'Agusman Anwar Indra Gunawan Nehe', 'L', 14, 'Tidak Hadir'),
('57211527', '57211527', 'Wildayanti Sarumaha', 'P', 24, 'Tidak Hadir'),
('57219482', '57219482', 'Albert Oldo Faoso Laia', 'L', 22, 'Tidak Hadir'),
('57272108', '57272108', 'Ori Imanuel Zebua', 'L', 14, 'Tidak Hadir'),
('57306900', '57306900', 'Alta Evelyn Nifolai Dachi', 'P', 14, 'Tidak Hadir'),
('57424506', '57424506', 'Alberta Fau', 'P', 15, 'Tidak Hadir'),
('57492916', '57492916', 'Federson Halawa', 'L', 14, 'Tidak Hadir'),
('57507265', '57507265', 'Arjun Buala Iman Duha', 'L', 13, 'Tidak Hadir'),
('57537199', '57537199', 'Yohanes Newman A. Sarumaha', 'L', 23, 'Tidak Hadir'),
('57620418', '57620418', 'Josia Sodani Cressendo Dachi', 'L', 13, 'Tidak Hadir'),
('57697569', '57697569', 'Hanni Bernike Wau', 'P', 23, 'Tidak Hadir'),
('57726926', '57726926', 'Kosmas Sanofu Fau', 'L', 20, 'Tidak Hadir'),
('57783821', '57783821', 'Vivin Karnila Luahambowo', 'P', 14, 'Tidak Hadir'),
('57864469', '57864469', 'Katrin Normalina Ge\'e', 'P', 15, 'Tidak Hadir'),
('57895434', '57895434', 'Prita Ohanda Sari Laia', 'P', 14, 'Tidak Hadir'),
('57903457', '57903457', 'Mayla Sabrina Telaumbanua', 'P', 13, 'Tidak Hadir'),
('58057116', '58057116', 'Kisah Sasty Ziraluo', 'P', 22, 'Tidak Hadir'),
('58392412', '58392412', 'Hamdi Azwar Buaya', 'L', 13, 'Tidak Hadir'),
('58426078', '58426078', 'Maya Kurnia Aprianti Zebua', 'P', 14, 'Tidak Hadir'),
('58462356', '58462356', 'Yabes Nifosikha Zataro Fau', 'L', 24, 'Tidak Hadir'),
('58462538', '58462538', 'Winning Julistin Gloria Faomasi ', 'P', 13, 'Tidak Hadir'),
('58520312', '58520312', 'Agnes Monika Harita', 'P', 19, 'Tidak Hadir'),
('58789679', '58789679', 'Hazryah Rahmayani Zebua', 'P', 13, 'Tidak Hadir'),
('58795100', '58795100', 'Angelina Rejeki Srimas Duha', 'P', 21, 'Tidak Hadir'),
('58797583', '58797583', 'Maychel Gregorius Sarumaha', 'L', 23, 'Tidak Hadir'),
('59024762', '59024762', 'Rialistis Karunia Duha', 'P', 18, 'Tidak Hadir'),
('59103641', '59103641', 'Risky Putra Natanael Harefa', 'L', 15, 'Tidak Hadir'),
('59235135', '59235135', 'Fakhrun Rizki Waruwu', 'L', 13, 'Tidak Hadir'),
('59237386', '59237386', 'Gracesia Rigimbarasi Fau', 'P', 19, 'Tidak Hadir'),
('59285419', '59285419', 'Nebo Efron Panjaitan', 'L', 21, 'Tidak Hadir'),
('59361583', '59361583', 'Paulinus Erdin Syah Putra Saruma', 'L', 23, 'Tidak Hadir'),
('59519359', '59519359', 'Octaviany Rubentiarini Claudia P', 'P', 13, 'Tidak Hadir'),
('59576702', '59576702', 'Hesti Putri Sanulo Duha', 'P', 14, 'Tidak Hadir'),
('59688469', '59688469', 'Yesica Nehe', 'P', 20, 'Tidak Hadir'),
('59714871', '59714871', 'Yabes Varel Fanolo Wa\'u', 'L', 13, 'Tidak Hadir'),
('59791476', '59791476', 'Kristof Darmawan Gaho', 'L', 24, 'Tidak Hadir'),
('59804413', '59804413', 'Yizhar Saputra Hondro', 'L', 14, 'Tidak Hadir'),
('59867727', '59867727', 'Mikar Wati Harefa', 'P', 14, 'Tidak Hadir'),
('59946133', '59946133', 'Ribcah Gracia Sanora Bidaya', 'P', 22, 'Tidak Hadir'),
('61521633', '61521633', 'Lily Muharni Halawa', 'P', 15, 'Tidak Hadir'),
('61705209', '61705209', 'Gracianus Putra Samurai Dakhi', 'L', 14, 'Tidak Hadir'),
('62464603', '62464603', 'Bintang Pratiwi Bago', 'P', 15, 'Tidak Hadir'),
('64810889', '64810889', 'Hermansyah Don Bosko Ndruru', 'L', 14, 'Tidak Hadir'),
('65025827', '65025827', 'Jeslinda Dakhi', 'P', 15, 'Tidak Hadir'),
('65093364', '65093364', 'Ardianto Dakhi', 'L', 13, 'Tidak Hadir'),
('65412024', '65412024', 'Krene Dwisartika Dakhi', 'P', 14, 'Tidak Hadir'),
('65481808', '65481808', 'Yanglis Manao', 'P', 14, 'Tidak Hadir'),
('66118891', '66118891', 'Julia Trisnawati Duha', 'P', 13, 'Tidak Hadir'),
('66758734', '66758734', 'Elvira Kartini Lature', 'P', 13, 'Tidak Hadir'),
('67016267', '67016267', 'Kelvin Hondro', 'L', 15, 'Tidak Hadir'),
('67396291', '67396291', 'Ester Renata Yolanda Dakhi', 'P', 13, 'Tidak Hadir'),
('67636097', '67636097', 'Glendo Michael Adman Wau', 'L', 13, 'Tidak Hadir'),
('67989989', '67989989', 'Dhea Safista Gea', 'P', 14, 'Tidak Hadir'),
('68133509', '68133509', 'Monica Ellena', 'P', 13, 'Tidak Hadir'),
('68395319', '68395319', 'Anglis Aisan Pulwandandari Satof', 'P', 15, 'Tidak Hadir'),
('68538455', '68538455', 'Nesya Tannia Hulu', 'P', 15, 'Tidak Hadir'),
('77926378', '77926378', 'Oshin Dachi', 'P', 14, 'Tidak Hadir'),
('9013353684', '9013353684', 'Efrain Gaurifa', 'L', 14, 'Tidak Hadir'),
('9016340010', '9016340010', 'Richard Pranaya Ziraluo', 'L', 14, 'Tidak Hadir'),
('9018950296', '9018950296', 'Pethersond Putra Triyadil Nehe', 'L', 15, 'Tidak Hadir'),
('username', 'password', 'nm_siswa', 'j', 0, 'hadir');

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `view_daftarhadir`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `view_daftarhadir` (
`NISN` varchar(32)
,`nm_siswa` varchar(32)
,`nm_kelas` varchar(32)
);

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `view_vote`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `view_vote` (
`nisn` varchar(32)
,`nama` varchar(32)
,`photo` varchar(32)
,`no` int(1)
,`username` varchar(32)
);

-- --------------------------------------------------------

--
-- Struktur untuk view `view_daftarhadir`
--
DROP TABLE IF EXISTS `view_daftarhadir`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_daftarhadir`  AS SELECT `tb_siswa`.`username` AS `NISN`, `tb_siswa`.`nm_siswa` AS `nm_siswa`, `tb_kelas`.`nm_kelas` AS `nm_kelas` FROM ((`tb_siswa` join `tb_kelas` on(`tb_kelas`.`kd_kelas` = `tb_siswa`.`kd_kelas`)) join `tb_pilih` on(`tb_siswa`.`username` = `tb_pilih`.`username`)) ;

-- --------------------------------------------------------

--
-- Struktur untuk view `view_vote`
--
DROP TABLE IF EXISTS `view_vote`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_vote`  AS SELECT `tb_pilihan`.`nisn` AS `nisn`, `tb_pilihan`.`nama` AS `nama`, `tb_pilihan`.`photo` AS `photo`, `tb_pilihan`.`no` AS `no`, `tb_siswa`.`username` AS `username` FROM ((`tb_pilih` join `tb_pilihan` on(`tb_pilihan`.`nisn` = `tb_pilih`.`nisn`)) join `tb_siswa` on(`tb_siswa`.`username` = `tb_pilih`.`username`)) ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`username`);

--
-- Indeks untuk tabel `tb_datapilketos`
--
ALTER TABLE `tb_datapilketos`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_identitassekolah`
--
ALTER TABLE `tb_identitassekolah`
  ADD PRIMARY KEY (`npsn`);

--
-- Indeks untuk tabel `tb_kelas`
--
ALTER TABLE `tb_kelas`
  ADD PRIMARY KEY (`kd_kelas`);

--
-- Indeks untuk tabel `tb_pilih`
--
ALTER TABLE `tb_pilih`
  ADD PRIMARY KEY (`id_pilih`);

--
-- Indeks untuk tabel `tb_pilihan`
--
ALTER TABLE `tb_pilihan`
  ADD PRIMARY KEY (`nisn`);

--
-- Indeks untuk tabel `tb_siswa`
--
ALTER TABLE `tb_siswa`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_kelas`
--
ALTER TABLE `tb_kelas`
  MODIFY `kd_kelas` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT untuk tabel `tb_pilih`
--
ALTER TABLE `tb_pilih`
  MODIFY `id_pilih` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
