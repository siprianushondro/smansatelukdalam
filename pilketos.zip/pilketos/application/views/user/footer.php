
<script src="<?php echo base_url(); ?>asset/vendor/jquery/jquery.js"></script>
<script src="<?php echo base_url(); ?>asset/vendor/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>asset/vendor/datatables/datatables.min.js"></script>
<script src="<?php echo base_url(); ?>asset/vendor/responsive-tables/responsive-tables.js"></script>
</body>
</html>
